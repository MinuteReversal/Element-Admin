﻿/**
 * author      : 反转的分针
 * date        : 20170707
 * description : 远程加载页面并转化为组件
 */
var vueLoadComponent = {
    template: '<div v-loading="loading"><div></div></div>',
    props: {
        "url": {
            "type": String,
            "default": ""
        },
        "parameters": {
            "type": Object,
            "default": null
        },
        "value": {}
    },
    data: function () {
        return {
            loading: false,
            component: null,
            val: null
        }
    },
    methods: {
        loadComponent: function () {
            var me = this;
            me.loading = true;
            $f.getPageComponent({
                url: me.url,
                isBack: true,
                isChangeUrl: false,
                success: function (c) {
                    me.loading = false;
                    
                    me.component = new Vue(c);

                    if (me.parameters) $f.addParameters(me.component._uid, me.parameters);

                    me.component.$mount(me.$el.querySelector("div"));

                    me.val = me.component.$data;
                    me.$emit("load", me.component);
                },
                error: function (error) {
                    me.loading = false;
                    me.$message({
                        type: 'error',
                        message: error.message
                    });
                }
            });
        }
    },
    watch: {
        value: function (val, oldVal) {
            var me = this;
            Object.assign(me.component.$data, val);
        },
        val: function (val, oldVal) {
            var me = this;
            me.$emit("input", me.component.$data);
        }
    },
    mounted: function () {
        var me = this;
        me.loadComponent();
    },
    destroyed: function () {
        var me = this;
        $f.removeParameters(me.component._uid);
    }
};