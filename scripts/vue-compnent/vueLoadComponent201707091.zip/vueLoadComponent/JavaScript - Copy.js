﻿/**
 * author      : 反转的分针
 * date        : 20170702
 * description : 远程加载页面并转化为组件
 */
var vueLoadComponent = {
    template: '<div v-loading="loading"><div></div></div>',
    props: {
        "url": {
            "type": String,
            "default": ""
        }
    },
    data: function () {
        return {
            loading: false
        }
    },
    methods: {
        loadComponent: function () {
            var me = this;
            me.loading = true;
            $f.getPageComponent({
                url: me.url,
                isBack: true,
                isChangeUrl: false,
                success: function (c) {
                    me.loading = false;
                    c.el = me.$el.querySelector("div");
                    me.value = new Vue(c);
                    me.$emit("input", me.value);
                    me.$emit("load");
                },
                error: function (error) {
                    me.loading = false;
                    me.$message({
                        type: 'error',
                        message: error.message
                    });
                }
            });
        }
    },
    mounted: function () {
        this.loadComponent();
    }
};